<?php

require __DIR__ . '/vendor/autoload.php';
require 'vendor/autoload.php';


use Orhanerday\OpenAi\OpenAi;

// Replace with your actual OpenAI key
$open_ai_key = '5cb36707-f772-4d5c-b238-1406e967a28d';
$open_ai = new OpenAi($open_ai_key);

$response = '';
$prompt = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize the input prompt
    $prompt = htmlspecialchars(trim($_POST['prompt']));

    if (!empty($prompt)) {
        try {
            $complete = $open_ai->completion([
                'model' => 'text-davinci-003',
                'prompt' => 'Write 3 marketing Facebook captions for ' . $prompt,
                'temperature' => 0.9,
                'max_tokens' => 150,
                'frequency_penalty' => 0,
                'presence_penalty' => 0.6,
            ]);

            $responseData = json_decode($complete, true);
            $response = $responseData["choices"][0]["text"] ?? 'No response generated.';
        } catch (Exception $e) {
            $response = 'Error: ' . htmlspecialchars($e->getMessage());
        }
    } else {
        $response = 'Please provide a valid prompt.';
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Interior design Captions Generator</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        .output-text {
            white-space: pre-wrap; /* Preserves whitespace and line breaks */
            border: 1px solid #ccc;
            padding: 10px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <h1>Generate Interior design Captions <?=$prompt?></h1>
    <form method="POST">
        <label for="prompt">Enter your prompt:</label><br>
        <input type="text" id="prompt" name="prompt" value="<?= htmlspecialchars($prompt) ?>" required>
        <button type="submit">Generate Captions</button>
    </form>

    <?php if ($response): ?>
        <h2>Output for "<?= htmlspecialchars($prompt) ?>"</h2>
        <div class="output-text">
            <?= nl2br($response) ?>
        </div>
    <?php endif; ?>
</body>
</html>
