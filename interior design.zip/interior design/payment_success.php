<?php
include "header.php"; 


echo "<div class='payment-success'>";
echo "<h1>Payment Success</h1>";
echo "<p>Thank you for your payment! Your transaction has been processed successfully.</p>";
echo "</div>";

include "newslettter.php"; 
include "footer.php"; 














































